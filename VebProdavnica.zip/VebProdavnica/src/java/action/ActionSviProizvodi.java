/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package action;

import dao.Proizvod.DAOProizvodImpl;
import entity.Proizvod;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Tamara
 */
public class ActionSviProizvodi implements Action {

    @Override
    public String obradiZahtev(HttpServletRequest request) {
        String strana = null;
    
        DAOProizvodImpl dao = new DAOProizvodImpl() {};
        List<Proizvod> listaProizvoda = dao.vratiListu();
        
        strana = "svi_proizvodi";
        
        HttpSession sesija = request.getSession(true);
        sesija.setAttribute("svi_proizvodi", listaProizvoda);
        
       
        return strana;
    }

    
}
