/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package view;

/**
 *
 * @author student1
 */
public class LookUpView {

    public static String getView(String ime) {
        String view = null;
        if (ime.equalsIgnoreCase("svi_proizvodi")) {
            view = "/WEB-INF/svi_proizvodi.jsp";
        }
       
        return view;
    }
}
