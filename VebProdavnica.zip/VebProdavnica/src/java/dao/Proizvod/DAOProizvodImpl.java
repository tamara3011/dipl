/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.Proizvod;

import entity.Proizvod;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Tamara
 */
public class DAOProizvodImpl implements DAOProizvod{

    @Override
    public List<Proizvod> vratiListu() {
        
       EntityManagerFactory emf = Persistence.createEntityManagerFactory("VebProdavnicaPU");
       EntityManager em = emf.createEntityManager();
       List<Proizvod> listaProizvoda = em.createQuery("SELECT * FROM Proizvod  ").getResultList();
       em.close();
       emf.close();
       
       return listaProizvoda;
    }

    @Override
    public Proizvod vratiProizvod(String kriterijum) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void sacuvaj(Proizvod p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void izmeni(Proizvod p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void obrisi(Proizvod p) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
