/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao.Proizvod;

import entity.Proizvod;
import java.util.List;

/**
 *
 * @author Tamara
 */
public interface DAOProizvod {

    public List<Proizvod> vratiListu();
    public Proizvod vratiProizvod(String kriterijum);
    public void sacuvaj(Proizvod p);
    public void izmeni(Proizvod p);
    public void obrisi(Proizvod p);
 
}
